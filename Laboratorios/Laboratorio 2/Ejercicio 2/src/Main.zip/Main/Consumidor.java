package Main;

public class Consumidor extends Thread {

    public Consumidor() {

    }

    @Override
    public void run() {
        int numero;
        int i = 0;
        try {
            System.out.println("El consumidor está pidiendo permiso");
            Main.sem1.acquire(1);
            System.out.println("El consumidor ha conseguido autorización");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        while (i < Main.buffer.length) {
            numero = Main.buffer[i];
            System.out.println("El consumidor obtiene el numero: " + numero);
            Main.sem1.release(0);
            try {
                Thread.sleep(1000);
            } catch (Exception e) {
                System.out.println(e);
            }
            i++;
        }
    }
}
